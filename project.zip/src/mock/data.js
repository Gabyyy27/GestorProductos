const mockProducts = [
  {
    id: 1,
    name: "MacBook Pro 14\"",
    category: "Tecnología",
    price: 1999.99,
    cost: 1499.99,
    image: "https://via.placeholder.com/300"
  },
  {
    id: 2,
    name: "Teclado Mecánico RGB",
    category: "Accesorios",
    price: 129.99,
    cost: 59.99,
    image: "https://via.placeholder.com/300"
  },
  {
    id: 3,
    name: "Mouse Inalámbrico",
    category: "Accesorios",
    price: 49.99,
    cost: 19.99,
    image: "https://via.placeholder.com/300"
  }
];

export { mockProducts };